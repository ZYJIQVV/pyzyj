<center><font size=7><b>PyZYJ</b></font></center>
ZYJ's <b>OWN</b> python tools.

[![PyPI version](https://badge.fury.io/py/pyzyj.svg)](https://badge.fury.io/py/pyzyj)
[![GitHub license](https://img.shields.io/github/license/ZYJIQVV/pyzyj)](https://img.shields.io/github/license/ZYJIQVV/pyzyj)

[//]: # ([![GitHub version]&#40;https://badge.fury.io/gh/ZYJIQVV%2Fpyzyj.svg&#41;]&#40;https://badge.fury.io/gh/ZYJIQVV%2Fpyzyj&#41;)

Version `1.1.9` Release

[Source Code Available on GitHub](https://github.com/ZYJIQVV/pyzyj)

This is a collection of Python tools I have written for my own work.
I have decided to publish it as a package on `PyPI` and `GitHub` so that it can be installed and used in any of my projects.
These tools are currently mainly used for data processing, data analysis, and data visualization.
It will continue to be updated in the future.

`update.py` may have to run under admin permission. It can run in a cmd terminal or in a python environment with admin permission.